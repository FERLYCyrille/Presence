

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Marquer votre présence</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>


    <form method="POST" action="<?php echo e(route('presence.store')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Marquer ma présence</button>
    </form>

    <h2>Historique de présence</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Heure d'arrivée</th>
                <th>Heure de départ</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $presences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($presence->date); ?></td>
                    <td><?php echo e($presence->time_in); ?></td>
                    <td><?php echo e($presence->time_out); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyril\Documents\laravel\vite\nom_du_projet\resources\views/presence/index.blade.php ENDPATH**/ ?>